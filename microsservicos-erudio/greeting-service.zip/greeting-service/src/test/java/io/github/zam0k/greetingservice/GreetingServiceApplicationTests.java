package io.github.zam0k.greetingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreetingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
